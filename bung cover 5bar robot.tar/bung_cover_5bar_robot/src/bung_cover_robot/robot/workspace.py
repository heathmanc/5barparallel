"""Workspace safety for the 5-bar robot.

This is the guard that stands between vision-computed targets and the PLC.
A target is only *safe* if it is:
  1. geometrically reachable by both arms,
  2. inside the shoulder joint limits,
  3. far enough from a PARALLEL singularity (distal links near-collinear),
  4. far enough from a SERIAL singularity (an arm near full extension / fold),
  5. within the stiffness cap (TCP not beyond a set fraction of full reach).

Any of these failing must stop the target from being sent. The verified design
point keeps the whole battery + pick zone well inside all five checks.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np

from .fivebar_kinematics import (
    FiveBarConfig,
    FiveBarKinematics,
    JointTarget,
    KinematicsError,
)


@dataclass
class SingularityLimits:
    """Thresholds for the workspace guard (degrees, and a unitless fraction).

    Defaults are the engineering values used in the design review:
      * 20 deg from collinear distal links (parallel singularity),
      * 15 deg from straight/folded arms (serial singularity),
      * TCP within 85 % of full reach (stiffness).
    """
    parallel_min_deg: float = 20.0
    serial_min_deg: float = 15.0
    reach_fraction_max: float = 0.85


@dataclass
class ValidationResult:
    ok: bool
    reason: str
    parallel_margin_deg: float
    serial_margin_deg: float
    reach_fraction: float
    joint_target: Optional[JointTarget]

    def __bool__(self) -> bool:
        return self.ok


def _angle_between(u: np.ndarray, v: np.ndarray) -> float:
    nu, nv = np.hypot(*u), np.hypot(*v)
    if nu < 1e-9 or nv < 1e-9:
        return 0.0
    c = np.clip(float(np.dot(u, v)) / (nu * nv), -1.0, 1.0)
    return float(np.degrees(np.arccos(c)))


class WorkspaceValidator:
    """Full go/no-go validation for TCP targets."""

    def __init__(self, kinematics: Optional[FiveBarKinematics] = None,
                 limits: Optional[SingularityLimits] = None) -> None:
        self.kin = kinematics or FiveBarKinematics()
        self.limits = limits or SingularityLimits()

    # ------------------------------------------------------------------ #
    # Metrics
    # ------------------------------------------------------------------ #
    def parallel_margin_deg(self, x_mm: float, y_mm: float) -> float:
        """Degrees from a parallel (direct-kinematic) singularity.

        0 => the two distal links are collinear (mechanism loses control of
        one DOF). Larger is safer. NaN if unreachable.
        """
        try:
            jt = self.kin.inverse(x_mm, y_mm)
        except KinematicsError:
            return float("nan")
        tcp = np.array([x_mm, y_mm])
        d1 = tcp - np.array(jt.left_elbow_xy)
        d2 = tcp - np.array(jt.right_elbow_xy)
        ang = _angle_between(d1, d2)
        return min(ang, 180.0 - ang)

    def serial_margin_deg(self, x_mm: float, y_mm: float) -> float:
        """Degrees from a serial (inverse-kinematic) singularity: the smaller,
        over the two arms, of |angle from straight| and |angle from folded|.
        0 => an arm is fully extended or fully folded. NaN if unreachable.
        """
        try:
            jt = self.kin.inverse(x_mm, y_mm)
        except KinematicsError:
            return float("nan")
        tcp = np.array([x_mm, y_mm])
        out = []
        for base, elbow in ((self.kin.cfg.left_base, jt.left_elbow_xy),
                            (self.kin.cfg.right_base, jt.right_elbow_xy)):
            prox = np.array(elbow) - base
            dist = tcp - np.array(elbow)
            ang = _angle_between(prox, dist)
            out.append(min(ang, 180.0 - ang))
        return min(out)

    def reach_fraction(self, x_mm: float, y_mm: float) -> float:
        """Max over both arms of |TCP - base| / (L1 + L2). 1.0 = full
        extension. Values above ``reach_fraction_max`` are too compliant."""
        tcp = np.array([x_mm, y_mm])
        dl = np.hypot(*(tcp - self.kin.cfg.left_base))
        dr = np.hypot(*(tcp - self.kin.cfg.right_base))
        return float(max(dl, dr) / self.kin.cfg.max_reach_mm)

    # ------------------------------------------------------------------ #
    # The guard
    # ------------------------------------------------------------------ #
    def validate(self, x_mm: float, y_mm: float) -> ValidationResult:
        """Full go/no-go for a TCP target. Never raises; returns a result
        whose ``reason`` explains any rejection."""
        # 1. reachable?
        try:
            jt = self.kin.inverse(x_mm, y_mm)
        except KinematicsError as exc:
            return ValidationResult(False, f"unreachable: {exc}",
                                    float("nan"), float("nan"),
                                    self.reach_fraction(x_mm, y_mm), None)

        # 2. joint limits?
        if not self.kin.within_joint_limits(jt.left_deg, jt.right_deg):
            return ValidationResult(
                False,
                f"joint limit: L={jt.left_deg:.1f}deg R={jt.right_deg:.1f}deg "
                f"outside "
                f"[{self.kin.cfg.left_min_deg},{self.kin.cfg.left_max_deg}]/"
                f"[{self.kin.cfg.right_min_deg},{self.kin.cfg.right_max_deg}]",
                self.parallel_margin_deg(x_mm, y_mm),
                self.serial_margin_deg(x_mm, y_mm),
                self.reach_fraction(x_mm, y_mm), jt)

        par = self.parallel_margin_deg(x_mm, y_mm)
        ser = self.serial_margin_deg(x_mm, y_mm)
        rf = self.reach_fraction(x_mm, y_mm)

        # 3. parallel singularity
        if par < self.limits.parallel_min_deg:
            return ValidationResult(
                False, f"near parallel singularity ({par:.1f}deg < "
                       f"{self.limits.parallel_min_deg}deg)",
                par, ser, rf, jt)
        # 4. serial singularity
        if ser < self.limits.serial_min_deg:
            return ValidationResult(
                False, f"near serial singularity / full extension "
                       f"({ser:.1f}deg < {self.limits.serial_min_deg}deg)",
                par, ser, rf, jt)
        # 5. stiffness
        if rf > self.limits.reach_fraction_max:
            return ValidationResult(
                False, f"beyond stiffness cap ({rf*100:.0f}% > "
                       f"{self.limits.reach_fraction_max*100:.0f}% of reach)",
                par, ser, rf, jt)

        return ValidationResult(True, "ok", par, ser, rf, jt)

    def is_safe(self, x_mm: float, y_mm: float) -> bool:
        return self.validate(x_mm, y_mm).ok

    # ------------------------------------------------------------------ #
    # Offline helper (commissioning / plotting)
    # ------------------------------------------------------------------ #
    def scan(self, x_range: tuple[float, float, float],
             y_range: tuple[float, float, float]) -> tuple[np.ndarray, ...]:
        """Sample a grid; return (X, Y, safe_mask). Handy for regenerating the
        workspace maps used in the design review. Not used at runtime."""
        xs = np.arange(*x_range)
        ys = np.arange(*y_range)
        X, Y = np.meshgrid(xs, ys)
        safe = np.zeros(X.shape, bool)
        for i in range(X.shape[0]):
            for j in range(X.shape[1]):
                safe[i, j] = self.is_safe(float(X[i, j]), float(Y[i, j]))
        return X, Y, safe
