"""Five-bar parallel-SCARA kinematics for the bung-cover robot.

Robot frame convention (matches config/robot_config.yaml):
  * The two shoulder bases lie on the X axis (Y = 0).
  * The mechanism reaches into +Y.
  * Angles are measured CCW from +X, in degrees.

The mechanism is two 2-link arms (proximal L1 + distal L2) that meet at a
common TCP. Each arm has an independent elbow "assembly branch" (up / down).

World <-> robot-frame placement (inline mount beside the conveyor, ~260 mm
standoff, etc.) is handled by the vision calibration transform, NOT here. This
module is pure robot-frame geometry so it can be unit-tested in isolation.

Verified design point (see project design review):
    L1 = 220 mm, L2 = 230 mm, base spacing 101.6 mm (4 in), left-up/right-down.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Literal, Optional

import numpy as np

ElbowBranch = Literal["up", "down"]


class KinematicsError(Exception):
    """Raised when a TCP target cannot be resolved to valid joint angles
    (outside the annular reach envelope of one or both arms)."""


@dataclass
class FiveBarConfig:
    """Geometry, joint limits, and drivetrain scaling for the 5-bar.

    Defaults are the verified design point. Override via ``from_yaml`` or by
    constructing directly.
    """

    # --- link geometry (mm) ---
    primary_link_mm: float = 220.0      # L1, shoulder -> elbow
    distal_link_mm: float = 230.0       # L2, elbow -> TCP

    # --- base positions (mm), on the X axis ---
    left_base_x_mm: float = -50.8       # 4 in spacing, symmetric
    left_base_y_mm: float = 0.0
    right_base_x_mm: float = 50.8
    right_base_y_mm: float = 0.0

    # --- assembly branches ---
    left_elbow: ElbowBranch = "up"
    right_elbow: ElbowBranch = "down"

    # --- joint limits & offsets (degrees, geometric shoulder angle) ---
    left_min_deg: float = -20.0
    left_max_deg: float = 200.0
    right_min_deg: float = -20.0
    right_max_deg: float = 200.0
    left_offset_deg: float = 0.0        # geometric angle at motor "zero"
    right_offset_deg: float = 0.0

    # --- drivetrain ---
    drive_pulses_per_motor_rev: int = 3200
    belt_reduction: float = 3.0

    # ------------------------------------------------------------------ #
    @property
    def pulses_per_degree(self) -> float:
        """Output-shaft pulses per degree of shoulder rotation."""
        return self.drive_pulses_per_motor_rev * self.belt_reduction / 360.0

    @property
    def max_reach_mm(self) -> float:
        return self.primary_link_mm + self.distal_link_mm

    @property
    def min_reach_mm(self) -> float:
        return abs(self.primary_link_mm - self.distal_link_mm)

    @property
    def left_base(self) -> np.ndarray:
        return np.array([self.left_base_x_mm, self.left_base_y_mm], float)

    @property
    def right_base(self) -> np.ndarray:
        return np.array([self.right_base_x_mm, self.right_base_y_mm], float)

    @property
    def base_spacing_mm(self) -> float:
        return float(np.hypot(self.right_base_x_mm - self.left_base_x_mm,
                              self.right_base_y_mm - self.left_base_y_mm))

    @classmethod
    def from_yaml(cls, path: str | Path) -> "FiveBarConfig":
        import yaml
        data = yaml.safe_load(Path(path).read_text())
        g = data["robot"]["geometry"]
        j = data["robot"]["joints"]
        d = data["robot"]["drivetrain"]
        return cls(
            primary_link_mm=g["primary_link_mm"],
            distal_link_mm=g["distal_link_mm"],
            left_base_x_mm=g["left_base_x_mm"],
            left_base_y_mm=g["left_base_y_mm"],
            right_base_x_mm=g["right_base_x_mm"],
            right_base_y_mm=g["right_base_y_mm"],
            left_elbow=g["left_elbow"],
            right_elbow=g["right_elbow"],
            left_min_deg=j["left_min_deg"],
            left_max_deg=j["left_max_deg"],
            right_min_deg=j["right_min_deg"],
            right_max_deg=j["right_max_deg"],
            left_offset_deg=j.get("left_offset_deg", 0.0),
            right_offset_deg=j.get("right_offset_deg", 0.0),
            drive_pulses_per_motor_rev=d["drive_pulses_per_motor_rev"],
            belt_reduction=d["belt_reduction"],
        )


@dataclass
class JointTarget:
    """Result of an inverse-kinematics solve."""
    left_deg: float
    right_deg: float
    left_pulses: int
    right_pulses: int
    tcp_x_mm: float
    tcp_y_mm: float
    left_elbow_xy: tuple[float, float]
    right_elbow_xy: tuple[float, float]


def _circle_intersections(
    c0: np.ndarray, r0: float, c1: np.ndarray, r1: float
) -> Optional[tuple[np.ndarray, np.ndarray]]:
    """Two intersection points of circles (c0,r0) and (c1,r1), or None.

    Returns the pair ``(p_plus, p_minus)`` where ``p_plus`` is offset along
    +perp (perp = 90deg CCW of c0->c1) and ``p_minus`` along -perp.
    """
    d_vec = c1 - c0
    d = float(np.hypot(*d_vec))
    if d < 1e-9:
        return None                      # concentric
    if d > r0 + r1 + 1e-9:
        return None                      # too far apart
    if d < abs(r0 - r1) - 1e-9:
        return None                      # one contains the other
    a = (r0 * r0 - r1 * r1 + d * d) / (2 * d)
    h_sq = r0 * r0 - a * a
    h = np.sqrt(max(h_sq, 0.0))
    foot = c0 + a * d_vec / d
    perp = np.array([-d_vec[1], d_vec[0]]) / d
    return foot + h * perp, foot - h * perp


class FiveBarKinematics:
    """Robot-frame forward/inverse kinematics and joint scaling."""

    def __init__(self, config: Optional[FiveBarConfig] = None) -> None:
        self.cfg = config or FiveBarConfig()

    # ------------------------------------------------------------------ #
    # Elbow / branch helpers
    # ------------------------------------------------------------------ #
    def _elbow(self, base: np.ndarray, tcp: np.ndarray, branch: ElbowBranch
               ) -> Optional[np.ndarray]:
        """Elbow position for one arm, or None if the arm cannot reach tcp.

        The elbow lies on circle(base, L1) and circle(tcp, L2). The two
        solutions are disambiguated by which side of the base->tcp line the
        elbow sits on; "up" = +perp side.
        """
        pts = _circle_intersections(base, self.cfg.primary_link_mm,
                                    tcp, self.cfg.distal_link_mm)
        if pts is None:
            return None
        p_plus, p_minus = pts
        return p_plus if branch == "up" else p_minus

    @staticmethod
    def _normalize_into_range(angle_deg: float, lo_deg: float) -> float:
        """Map an angle into ``[lo_deg, lo_deg + 360)``.

        ``atan2`` returns the principal value in (-180, 180], but a shoulder
        whose valid range is e.g. [-20, 200] can legitimately sit at 185deg,
        which ``atan2`` reports as -175deg. Normalizing into the joint's own
        360deg window makes the limit check see the true physical angle.
        """
        return lo_deg + ((angle_deg - lo_deg) % 360.0)

    # ------------------------------------------------------------------ #
    # Reachability (geometric only — see workspace.py for full safety)
    # ------------------------------------------------------------------ #
    def is_reachable(self, x_mm: float, y_mm: float) -> bool:
        """True iff both arms can physically close on the TCP.

        This is the *geometric* envelope only. It does NOT check joint
        limits, singularity margins, or stiffness — use
        ``workspace.WorkspaceValidator`` for the full go/no-go that guards
        the PLC.
        """
        tcp = np.array([x_mm, y_mm], float)
        return (self._elbow(self.cfg.left_base, tcp, self.cfg.left_elbow)
                is not None
                and self._elbow(self.cfg.right_base, tcp, self.cfg.right_elbow)
                is not None)

    # ------------------------------------------------------------------ #
    # Inverse kinematics
    # ------------------------------------------------------------------ #
    def inverse(self, x_mm: float, y_mm: float) -> JointTarget:
        """TCP (x, y) in robot mm -> shoulder angles + pulse counts.

        Raises ``KinematicsError`` if the target is outside the reach
        envelope of either arm.
        """
        tcp = np.array([x_mm, y_mm], float)

        elbow_l = self._elbow(self.cfg.left_base, tcp, self.cfg.left_elbow)
        elbow_r = self._elbow(self.cfg.right_base, tcp, self.cfg.right_elbow)
        if elbow_l is None or elbow_r is None:
            raise KinematicsError(
                f"TCP ({x_mm:.1f}, {y_mm:.1f}) mm is unreachable "
                f"(reach envelope {self.cfg.min_reach_mm:.0f}"
                f"–{self.cfg.max_reach_mm:.0f} mm per arm)."
            )

        left_deg = self._normalize_into_range(float(np.degrees(np.arctan2(
            elbow_l[1] - self.cfg.left_base_y_mm,
            elbow_l[0] - self.cfg.left_base_x_mm))), self.cfg.left_min_deg)
        right_deg = self._normalize_into_range(float(np.degrees(np.arctan2(
            elbow_r[1] - self.cfg.right_base_y_mm,
            elbow_r[0] - self.cfg.right_base_x_mm))), self.cfg.right_min_deg)

        return JointTarget(
            left_deg=left_deg,
            right_deg=right_deg,
            left_pulses=self.degrees_to_pulses(left_deg, "left"),
            right_pulses=self.degrees_to_pulses(right_deg, "right"),
            tcp_x_mm=x_mm,
            tcp_y_mm=y_mm,
            left_elbow_xy=(float(elbow_l[0]), float(elbow_l[1])),
            right_elbow_xy=(float(elbow_r[0]), float(elbow_r[1])),
        )

    # ------------------------------------------------------------------ #
    # Forward kinematics (used for round-trip checks / diagnostics)
    # ------------------------------------------------------------------ #
    def forward(self, left_deg: float, right_deg: float) -> tuple[float, float]:
        """Shoulder angles -> TCP (x, y) mm.

        Picks the +Y assembly (the working side). Raises
        ``KinematicsError`` if the two distal links cannot close (angles
        place the elbows too far apart).
        """
        l1 = self.cfg.primary_link_mm
        l2 = self.cfg.distal_link_mm
        elbow_l = self.cfg.left_base + l1 * np.array(
            [np.cos(np.radians(left_deg)), np.sin(np.radians(left_deg))])
        elbow_r = self.cfg.right_base + l1 * np.array(
            [np.cos(np.radians(right_deg)), np.sin(np.radians(right_deg))])
        pts = _circle_intersections(elbow_l, l2, elbow_r, l2)
        if pts is None:
            raise KinematicsError(
                "Distal links cannot close for the given shoulder angles.")
        # working configuration = the higher-Y intersection
        return tuple(max(pts, key=lambda p: p[1]))  # type: ignore[return-value]

    # ------------------------------------------------------------------ #
    # Joint scaling
    # ------------------------------------------------------------------ #
    def degrees_to_pulses(self, angle_deg: float, axis: Literal["left", "right"]
                          ) -> int:
        offset = (self.cfg.left_offset_deg if axis == "left"
                  else self.cfg.right_offset_deg)
        return int(round((angle_deg - offset) * self.cfg.pulses_per_degree))

    def within_joint_limits(self, left_deg: float, right_deg: float) -> bool:
        c = self.cfg
        return (c.left_min_deg <= left_deg <= c.left_max_deg
                and c.right_min_deg <= right_deg <= c.right_max_deg)
