"""Tests for the 5-bar kinematics and workspace guard.

The most important test here is ``test_verified_layout_is_safe`` — it encodes
the design-review conclusion (the full battery hole line + cap pick point are
singularity-free with margin) as a regression check. If someone later edits the
geometry and breaks coverage, this fails.
"""

import os
import sys

import numpy as np
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from bung_cover_robot.robot.fivebar_kinematics import (  # noqa: E402
    FiveBarConfig,
    FiveBarKinematics,
    KinematicsError,
)
from bung_cover_robot.robot.workspace import (  # noqa: E402
    SingularityLimits,
    WorkspaceValidator,
)


@pytest.fixture
def kin() -> FiveBarKinematics:
    return FiveBarKinematics(FiveBarConfig())


@pytest.fixture
def validator(kin) -> WorkspaceValidator:
    return WorkspaceValidator(kin, SingularityLimits())


# --------------------------------------------------------------------------- #
# Robot-frame coordinates of the verified work zone.
# World (hole_x, 0) and pick (-50, 0) map to robot frame by translating the
# base center to the origin: X_r = X_world - 125, Y_r = Y_world + standoff.
# So every target sits at Y_r = 260 mm; X_r spans -175 (pick) .. +175 (far hole)
# --------------------------------------------------------------------------- #
STANDOFF = 250.0
HOLE_X_WORLD = np.linspace(30.0, 300.0, 6)
BASE_CENTER_X_WORLD = 125.0
VERIFIED_TARGETS_ROBOT = [
    (float(hx - BASE_CENTER_X_WORLD), STANDOFF) for hx in HOLE_X_WORLD
] + [(-50.0 - BASE_CENTER_X_WORLD, STANDOFF)]  # + cap pick point


# --------------------------------------------------------------------------- #
# Drivetrain
# --------------------------------------------------------------------------- #
def test_pulses_per_degree(kin):
    assert kin.cfg.pulses_per_degree == pytest.approx(26.6666667, abs=1e-4)


def test_base_spacing(kin):
    assert kin.cfg.base_spacing_mm == pytest.approx(101.6, abs=1e-6)


# --------------------------------------------------------------------------- #
# Inverse / forward round trip
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("x,y", VERIFIED_TARGETS_ROBOT)
def test_inverse_forward_roundtrip(kin, x, y):
    jt = kin.inverse(x, y)
    fx, fy = kin.forward(jt.left_deg, jt.right_deg)
    assert fx == pytest.approx(x, abs=1e-6)
    assert fy == pytest.approx(y, abs=1e-6)


def test_roundtrip_over_grid(kin):
    # dense round-trip over the clean region
    for x in np.arange(-150, 151, 15.0):
        for y in np.arange(200, 340, 15.0):
            if not kin.is_reachable(float(x), float(y)):
                continue
            jt = kin.inverse(float(x), float(y))
            fx, fy = kin.forward(jt.left_deg, jt.right_deg)
            assert fx == pytest.approx(x, abs=1e-4)
            assert fy == pytest.approx(y, abs=1e-4)


# --------------------------------------------------------------------------- #
# Reachability / errors
# --------------------------------------------------------------------------- #
def test_unreachable_raises(kin):
    # far beyond L1+L2 from either base
    with pytest.raises(KinematicsError):
        kin.inverse(0.0, 10_000.0)


def test_is_reachable_matches_inverse(kin):
    assert kin.is_reachable(0.0, 260.0) is True
    assert kin.is_reachable(0.0, 10_000.0) is False


# --------------------------------------------------------------------------- #
# Singularities
# --------------------------------------------------------------------------- #
def test_parallel_singularity_detected_near_base(validator):
    # Close to the base line, between the shoulders, the distal links approach
    # collinear -> small parallel margin -> unsafe.
    res = validator.validate(0.0, 120.0)  # in the parallel-singularity band
    assert res.ok is False


def test_serial_singularity_detected_at_full_extension(validator):
    # Just inside full reach on the centerline -> arms nearly straight.
    near_full = validator.kin.cfg.max_reach_mm - 5.0
    res = validator.validate(0.0, near_full)
    assert res.ok is False
    assert "extension" in res.reason or "serial" in res.reason or \
           "stiffness" in res.reason


# --------------------------------------------------------------------------- #
# THE regression check: verified layout must stay clean with margin
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("x,y", VERIFIED_TARGETS_ROBOT)
def test_verified_layout_is_safe(validator, x, y):
    res = validator.validate(x, y)
    assert res.ok, f"target ({x:.0f},{y:.0f}) rejected: {res.reason}"
    # design review measured ~35 deg worst-case margin over this zone
    assert res.parallel_margin_deg >= 30.0
    assert res.serial_margin_deg >= 30.0
    assert res.reach_fraction <= 0.85 + 1e-6


def test_verified_layout_tolerance_band(validator):
    # +/- 2 in cross-conveyor tolerance around each target must also be safe
    for x, _ in VERIFIED_TARGETS_ROBOT:
        for dy in (-50.8, 0.0, 50.8):
            res = validator.validate(x, STANDOFF + dy)
            assert res.ok, f"({x:.0f},{STANDOFF+dy:.0f}) rejected: {res.reason}"


# --------------------------------------------------------------------------- #
# Config from YAML
# --------------------------------------------------------------------------- #
def test_config_from_yaml():
    cfg_path = os.path.join(os.path.dirname(__file__), "..",
                            "config", "robot_config.yaml")
    cfg = FiveBarConfig.from_yaml(cfg_path)
    assert cfg.primary_link_mm == 220.0
    assert cfg.distal_link_mm == 230.0
    assert cfg.base_spacing_mm == pytest.approx(101.6, abs=1e-6)
    assert cfg.left_elbow == "up" and cfg.right_elbow == "down"
