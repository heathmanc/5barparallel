# Bung-Cover 5-Bar Robot

Vision-guided 5-bar parallel-SCARA robot that installs plastic bung covers into
the vent holes of a G31 battery on an indexing conveyor.

**Start here:** [`Claude.md`](./Claude.md) — full concept, verified design,
software boundaries, and build plan.

## Status
- Kinematics + workspace/singularity guard: implemented and tested.
- Vision, PLC comms, planner, cycle manager: to build (see `Claude.md` §14).

## Quick start
```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -e ".[dev]"
pytest -q
```

## Verified design point (see Claude.md §3)
Inline mount · L1 220 mm / L2 230 mm · 4 in base spacing · ~250 mm standoff ·
left-up/right-down · pulses/deg 26.667. Whole battery + pick zone is
singularity-free with ~31°+ margin.
